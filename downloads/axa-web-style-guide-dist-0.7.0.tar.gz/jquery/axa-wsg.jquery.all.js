(function() {
  (function($) {
    var Affix, Plugin;
    Affix = (function() {
      Affix.VERSION = '1.0.0';

      Affix.RESET = 'is-affixed is-affixed-top is-affixed-bottom';

      Affix.DEFAULTS = {
        offset: 0,
        target: window
      };

      function Affix(element, options) {
        this.options = $.extend({}, Affix.DEFAULTS, options);
        this.$target = $(this.options.target).on('scroll.axa.affix.data-api', $.proxy(this.checkPosition, this)).on('click.axa.affix.data-api', $.proxy(this.checkPositionWithEventLoop, this));
        this.$element = $(element);
        this.affixed = null;
        this.unpin = null;
        this.pinnedOffset = null;
        this.checkPosition();
      }

      Affix.prototype.getState = function(scrollHeight, height, offsetTop, offsetBottom) {
        var colliderHeight, colliderTop, initializing, position, scrollTop, targetHeight;
        scrollTop = this.$target.scrollTop();
        position = this.$element.offset();
        targetHeight = this.$target.height();
        if (offsetTop !== null && this.affixed === 'top') {
          if (scrollTop < offsetTop) {
            return 'top';
          } else {
            return false;
          }
        }
        if (this.affixed === 'bottom') {
          if (offsetTop !== null) {
            if (scrollTop + this.unpin <= position.top) {
              return false;
            } else {
              return 'bottom';
            }
          }
          if (scrollTop + targetHeight <= scrollHeight - offsetBottom) {
            return false;
          } else {
            return 'bottom';
          }
        }
        initializing = this.affixed === null;
        colliderTop = initializing ? scrollTop : position.top;
        colliderHeight = initializing ? targetHeight : height;
        if (offsetTop !== null && colliderTop <= offsetTop) {
          return 'top';
        }
        if (offsetBottom !== null && (colliderTop + colliderHeight >= scrollHeight - offsetBottom)) {
          return 'bottom';
        }
        return false;
      };

      Affix.prototype.getPinnedOffset = function() {
        var position, scrollTop;
        if (this.pinnedOffset) {
          return this.pinnedOffset;
        }
        this.$element.removeClass(Affix.RESET).addClass('is-affixed');
        scrollTop = this.$target.scrollTop();
        position = this.$element.offset();
        return (this.pinnedOffset = position.top - scrollTop);
      };

      Affix.prototype.checkPositionWithEventLoop = function() {
        return setTimeout($.proxy(this.checkPosition, this), 1);
      };

      Affix.prototype.checkPosition = function() {
        var affix, affixType, e, height, offset, offsetBottom, offsetTop, scrollHeight;
        if (!this.$element.is(':visible')) {
          return;
        }
        height = this.$element.height();
        offset = this.options.offset;
        offsetTop = offset.top;
        offsetBottom = offset.bottom;
        scrollHeight = $('body').height();
        if (typeof offset !== 'object') {
          offsetBottom = offsetTop = offset;
        }
        if (typeof offsetTop === 'function') {
          offsetTop = offset.top(this.$element);
        }
        if (typeof offsetBottom === 'function') {
          offsetBottom = offset.bottom(this.$element);
        }
        affix = this.getState(scrollHeight, height, offsetTop, offsetBottom);
        if (this.affixed !== affix) {
          if (this.unpin !== null) {
            this.$element.css('top', '');
          }
          affixType = 'is-affixed' + (affix ? '-' + affix : '');
          e = $.Event(affixType + '.axa.affix');
          this.$element.trigger(e);
          if (e.isDefaultPrevented()) {
            return;
          }
          this.affixed = affix;
          if (affix === 'bottom') {
            this.unpin = this.getPinnedOffset();
          } else {
            this.unpin = null;
          }
          this.$element.removeClass(Affix.RESET).addClass(affixType).trigger(affixType.replace('affix', 'affixed') + '.axa.affix');
        }
        if (affix === 'bottom') {
          return this.$element.offset({
            top: scrollHeight - height - offsetBottom
          });
        }
      };

      return Affix;

    })();
    Plugin = function(option) {
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        data = $this.data('axa.affix');
        options = typeof option === 'object' && option;
        if (!data) {
          $this.data('axa.affix', (data = new Affix(this, options)));
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.affix = Plugin;
    $.fn.affix.Constructor = Affix;
    return $(window).on('load', function() {
      return $('[data-spy="affix"]').each(function() {
        var $spy, data;
        $spy = $(this);
        data = $spy.data();
        data.offset = data.offset || {};
        if (data.offsetBottom !== null) {
          data.offset.bottom = data.offsetBottom;
        }
        if (data.offsetTop !== null) {
          data.offset.top = data.offsetTop;
        }
        return Plugin.call($spy, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Autocomplete, Plugin;
    Autocomplete = (function() {
      function Autocomplete(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.filtered = this.options.source;
        if (this.filtered == null) {
          this.filtered = [];
        }
        this.value = '';
        this.isMouseOver = false;
        this.$dropdown = $('<div class="autocomplete__suggestions"></div>');
        this.$dropdown.hide();
        this.$element.after(this.$dropdown);
        this.$element.on('keyup', this, function(event) {
          return event.data.filter(event);
        });
        this.$element.on('blur', this, function(event) {
          if (!event.data.isMouseOver) {
            return event.data.$dropdown.hide();
          }
        });
      }

      Autocomplete.prototype.filter = function(event) {
        var i, len, ref, text;
        if (this.value !== this.element.value) {
          this.value = this.element.value;
          this.filtered = (function() {
            var i, len, ref, results;
            ref = this.options.source;
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
              text = ref[i];
              if (text.indexOf(this.value) > -1) {
                results.push(text);
              }
            }
            return results;
          }).call(this);
          this.$dropdown.empty();
          ref = this.filtered;
          for (i = 0, len = ref.length; i < len; i++) {
            text = ref[i];
            this.$dropdown.append(this.createItem(text));
          }
          return this.$dropdown.show();
        }
      };

      Autocomplete.prototype.createItem = function(text) {
        var item;
        item = $('<div class="autocomplete__suggestions__item">' + text + '</div>');
        item.on('mouseover', this, function(event) {
          event.data.isMouseOver = true;
          return $(event.target).addClass('autocomplete__suggestions__item--selected');
        });
        item.on('mouseout', this, function(event) {
          event.data.isMouseOver = false;
          return $(event.target).removeClass('autocomplete__suggestions__item--selected');
        });
        item.on('click', this, function(event) {
          return event.data.selectItem(event);
        });
        return item;
      };

      Autocomplete.prototype.selectItem = function(event) {
        this.element.value = event.target.textContent;
        return this.$dropdown.hide();
      };

      return Autocomplete;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        $this = $(this);
        data = $this.data('axa.autocomplete');
        if (!data) {
          data = new Autocomplete(this, options);
          return $this.data('axa.autocomplete', data);
        }
      });
    };
    $.fn.autocomplete = Plugin;
    $.fn.autocomplete.Constructor = Autocomplete;
    return $(window).on('load', function() {
      return $('[data-autocomplete]').each(function() {
        var $autocomplete;
        $autocomplete = $(this);
        return Plugin.call($autocomplete);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Autogrow, Plugin;
    Autogrow = (function() {
      function Autogrow(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.init();
      }

      Autogrow.prototype.init = function() {
        this.minHeight = this.$element.height();
        this.shadow = $('<div></div>');
        this.shadow.css({
          position: 'absolute',
          top: -10000,
          left: -10000,
          width: this.$element.width(),
          'font-size': this.$element.css('font-size'),
          'font-family': this.$element.css('font-family'),
          'font-weight': this.$element.css('font-weight'),
          'line-height': this.$element.css('line-height'),
          resize: 'none',
          'word-wrap': 'break-word'
        });
        this.shadow.appendTo(document.body);
        this.$element.on('change keyup keydown', this, function(event) {
          return event.data.update(event);
        });
        return $(window).resize(this.update);
      };

      Autogrow.prototype.update = function(event) {
        var newHeight, val;
        ({
          times: function(string, number) {
            var r;
            r = '';
            while (num -= 1) {
              r += string;
            }
            return r;
          }
        });
        if (this.element) {
          val = this.element.value.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&/g, '&amp;').replace(/\n$/, '<br/>&nbsp;').replace(/\n/g, '<br/>').replace(/\s{2,}/g, function(space) {
            return times('&nbsp;', space.length - 1) + ' ';
          });
          if ((event != null) && (event.data != null) && event.data.event === 'keydown' && event.keyCode === 13) {
            val += '<br />';
          }
          this.shadow.css('width', this.$element.width());
          this.shadow.html(val);
          newHeight = Math.max(this.shadow.height(), this.minHeight);
          return this.$element.height(newHeight);
        }
      };

      return Autogrow;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.autogrow');
        if (!data) {
          data = new Autogrow(this);
          return $this.data('axa.autogrow', data);
        }
      });
    };
    $.fn.autogrow = Plugin;
    $.fn.autogrow.Constructor = Autogrow;
    return $(window).on('load', function() {
      return $('[data-autogrow="autogrow"]').each(function() {
        var $autogrow;
        $autogrow = $(this);
        return Plugin.call($autogrow);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Checkbox, Plugin;
    Checkbox = (function() {
      Checkbox.DEFAULTS;

      function Checkbox(element, options) {
        this.setCheckboxState = bind(this.setCheckboxState, this);
        this.handleKeyUp = bind(this.handleKeyUp, this);
        this.$element = $(element);
        this.$checkbox = this.$element.find('.checkbox__checkbox');
        this.$label = this.$element.find('.checkbox__label');
        this.options = $.extend({}, Checkbox.DEFAULTS, options);
        this.init();
      }

      Checkbox.prototype.init = function() {
        this.$checkbox.attr('tabindex', '-1');
        this.$label.attr('tabindex', '0');
        this.$element.addClass('checkbox--js');
        this.setCheckboxState();
        this.$checkbox.on('change', this.setCheckboxState);
        return this.$label.on('keyup', this.handleKeyUp);
      };

      Checkbox.prototype.handleKeyUp = function(e) {
        if (e.which === 32) {
          e.preventDefault();
          this.$checkbox.prop('checked', !(this.$checkbox.is(':checked')));
          return this.$checkbox.change();
        }
      };

      Checkbox.prototype.setCheckboxState = function() {
        if (this.$checkbox.is(':checked')) {
          return this.$element.addClass('is-active');
        } else {
          return this.$element.removeClass('is-active');
        }
      };

      return Checkbox;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, Checkbox.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.checkbox');
        if (!data) {
          data = new Checkbox(this, options);
          return $this.data('axa.checkbox', data);
        }
      });
    };
    $.fn.checkbox = Plugin;
    $.fn.checkbox.Constructor = Checkbox;
    return $(window).on('load', function() {
      return $('[data-checkbox]').each(function() {
        var $checkbox, data;
        $checkbox = $(this);
        data = $checkbox.data();
        return Plugin.call($checkbox, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  (function($) {
    var Datepicker, Emitter, Picker, Plugin, append;
    Emitter = (function() {
      function Emitter() {
        this.emit = bind(this.emit, this);
        this.on = bind(this.on, this);
        this.events = {
          select: []
        };
      }

      Emitter.prototype.on = function(eventName, cb) {
        return this.events[eventName].push(cb);
      };

      Emitter.prototype.emit = function(eventName) {
        var fx, i, len, ref, results;
        ref = this.events[eventName];
        results = [];
        for (i = 0, len = ref.length; i < len; i++) {
          fx = ref[i];
          results.push(fx.apply(null, Array.prototype.slice.call(arguments, 1)));
        }
        return results;
      };

      return Emitter;

    })();
    append = function(html, $parent) {
      var $el;
      $el = $(html);
      $parent.append($el);
      return $el;
    };
    Picker = (function(superClass) {
      extend(Picker, superClass);

      function Picker(moment1, displayWeek1, icons1) {
        var weekdays;
        this.moment = moment1;
        this.displayWeek = displayWeek1;
        this.icons = icons1;
        Picker.__super__.constructor.apply(this, arguments);
        this.date = this.moment();
        this.$element = $('<div class="picker" ></div>');
        if (this.displayWeek) {
          this.$element.addClass('picker--with-weeknumber');
        }
        this.$header = append('<div class="picker__header" ></div>', this.$element);
        this.$prev = append('<div class="picker__prev"></div>', this.$header);
        this.$prev.append(this.createIcon('prev'));
        this.$prev.on('click', this.onPrevClick.bind(this));
        this.$next = append('<div class="picker__next"></div>', this.$header);
        this.$next.append(this.createIcon('next'));
        this.$next.on('click', this.onNextClick.bind(this));
        this.$headline = append('<div class="picker__headline" ></div>', this.$header);
        this.$headline__month = append('<span class="picker__headline__month" ></span>', this.$headline);
        append('<span> </span>', this.$headline);
        this.$headline__year = append('<span></span>', this.$headline);
        this.$content = append('<div class="picker__content" ></div>', this.$element);
        this.$month = append('<div class="picker__month" ></div>', this.$content);
        weekdays = moment.localeData()._weekdaysMin;
        this.$weekHeadline = append('<div class="picker__week picker__week--headline"><div class="picker__day picker__day--headline">' + weekdays[1] + '</div><div class="picker__day picker__day--headline">' + weekdays[2] + '</div><div class="picker__day picker__day--headline">' + weekdays[3] + '</div><div class="picker__day picker__day--headline">' + weekdays[4] + '</div><div class="picker__day picker__day--headline">' + weekdays[5] + '</div><div class="picker__day picker__day--headline">' + weekdays[6] + '</div><div class="picker__day picker__day--headline">' + weekdays[0] + '</div></div>', this.$month);
        if (this.displayWeek) {
          this.$weekHeadline.prepend('<div class="picker__weeknumber picker__weeknumber--headline" ></div>');
        }
        this.updateDisplay();
      }

      Picker.prototype.updateDisplay = function() {
        var $week, $weeknumber, currentMonth, dateClone, modifier, month, results;
        this.$headline__month.text(this.date.format('MMMM'));
        this.$headline__year.text(this.date.format('YYYY'));
        this.$month.empty();
        this.$month.append(this.$weekHeadline);
        dateClone = this.moment(this.date);
        month = dateClone.get('month');
        dateClone.set('date', 1);
        if (dateClone.get('day') === 0) {
          dateClone.set('day', -6);
        } else {
          dateClone.set('day', 1);
        }
        results = [];
        while (true) {
          $week = append('<div class="picker__week" ></div>', this.$month);
          if (this.displayWeek) {
            $weeknumber = $('<div class="picker__weeknumber" ></div>');
            $weeknumber.text(dateClone.get('week'));
            $week.prepend($weeknumber);
          }
          while (true) {
            modifier = null;
            currentMonth = dateClone.get('month');
            if (currentMonth < month) {
              modifier = 'picker__day--prev-month';
            } else if (currentMonth > month) {
              modifier = 'picker__day--next-month';
            }
            append(this.createDay(dateClone, modifier), $week);
            dateClone.add(1, 'days');
            if (dateClone.get('day') === 1) {
              break;
            }
          }
          if (dateClone.get('month') !== month) {
            break;
          } else {
            results.push(void 0);
          }
        }
        return results;
      };

      Picker.prototype.createIcon = function(iconName) {
        var $icon, icon;
        icon = this.icons[iconName];
        if (icon == null) {
          $.error("Please define the " + iconName + " icon");
        }
        $icon = $('<svg version="1.1" xmlns="http://www.w3.org/2000/svg"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="' + icon + '" /></svg>');
        $icon.attr('class', 'picker__icon picker__icon--' + iconName);
        return $icon;
      };

      Picker.prototype.createDay = function(d, modifier) {
        var $day, date, self;
        date = this.moment(d);
        $day = $('<div class="picker__day" ></div>');
        if (modifier != null) {
          $day.addClass(modifier);
        }
        if ((this.selectedDate != null) && date.format('DD.MM.YYYY') === this.selectedDate.format('DD.MM.YYYY')) {
          $day.addClass('is-active');
        }
        if (date.format('DD.MM.YYYY') === this.moment().format('DD.MM.YYYY')) {
          $day.addClass('picker__day--today');
        }
        self = this;
        $day.text(date.get('date'));
        $day.on('click', function(e) {
          e.preventDefault();
          self.setSelectedDate(date);
          self.emit('select', date.format('DD.MM.YYYY'));
          return self.toggle();
        });
        return $day;
      };

      Picker.prototype.getDOMNode = function() {
        return this.$element;
      };

      Picker.prototype.toggle = function() {
        return this.$element.toggleClass('is-active');
      };

      Picker.prototype.setSelectedDate = function(selectedDate) {
        this.date = selectedDate;
        this.selectedDate = this.moment(selectedDate);
        return this.updateDisplay();
      };

      Picker.prototype.onPrevClick = function(e) {
        e.preventDefault();
        this.date.add(-1, 'months');
        return this.updateDisplay();
      };

      Picker.prototype.onNextClick = function(e) {
        e.preventDefault();
        this.date.add(1, 'months');
        return this.updateDisplay();
      };

      return Picker;

    })(Emitter);
    Datepicker = (function() {
      function Datepicker(element, moment1, input, displayWeek, icons) {
        this.moment = moment1;
        this.onChange = bind(this.onChange, this);
        this.$element = $(element);
        if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/(iOS|iPhone|iPad|iPod)/i) || navigator.userAgent.match(/Windows Phone/i)) {
          this.$input = $(input);
          this.$input.prop('type', 'date');
          this.$input.focus();
        } else {
          this.picker = new Picker(this.moment, displayWeek, icons);
          if (input != null) {
            this.$input = $(input);
            this.$input.on('change', this.onChange);
            this.onChange();
          }
          this.picker.on('select', (function(date) {
            this.$input.val(date);
            return this.$input.trigger('change');
          }).bind(this));
          this.$element.append(this.picker.getDOMNode());
        }
      }

      Datepicker.prototype.onChange = function() {
        var dat;
        dat = this.moment(this.$input.val(), 'DD.MM.YYYY');
        if (dat.isValid()) {
          return this.picker.setSelectedDate(dat);
        }
      };

      Datepicker.prototype.toggle = function() {
        return this.picker.toggle();
      };

      return Datepicker;

    })();
    Plugin = function(options) {
      var opts;
      opts = $.extend({}, $.fn.datepicker.defaults, options);
      return this.each(function() {
        var $this, data, moment;
        $this = $(this);
        data = $this.data('axa.datepicker');
        if (!data) {
          if (opts.moment != null) {
            moment = opts.moment;
          } else if (window.moment != null) {
            moment = window.moment;
          } else {
            $.error("Moment.js must either be passed as an option or be available globally");
          }
          data = new Datepicker(this, moment, opts.input, opts.displayWeek, opts.icons);
          $this.data('axa.datepicker', data);
        }
        if (opts.action != null) {
          return data[opts.action]();
        }
      });
    };
    $.fn.datepicker = Plugin;
    $.fn.datepicker.Constructor = Datepicker;
    return $(document).on('click.axa.datepicker.data-api', '[data-datepicker]', function(e) {
      var $input, $target, displayWeek, icons;
      e.preventDefault();
      $target = $($(this).data('datepicker'));
      $input = $($target.data('datepicker-watch'));
      displayWeek = $target.data('datepicker-display-week');
      icons = {
        prev: $target.data('datepicker-icon-prev'),
        next: $target.data('datepicker-icon-next')
      };
      displayWeek = displayWeek && displayWeek !== 'false';
      return Plugin.call($target, {
        input: $input,
        action: 'toggle',
        displayWeek: displayWeek,
        icons: icons
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Dropdown, Plugin;
    Dropdown = (function() {
      Dropdown.DEFAULTS;

      function Dropdown(element, options) {
        this.setLabelText = bind(this.setLabelText, this);
        this.handleKeyDown = bind(this.handleKeyDown, this);
        this.$element = $(element);
        this.$label = this.$element.find('.dropdown__label__text');
        this.$select = this.$element.find('.dropdown__select');
        this.options = $.extend({}, Dropdown.DEFAULTS, options);
        this.init();
      }

      Dropdown.prototype.init = function() {
        this.$select.attr('tabindex', '-1');
        this.$element.attr('tabindex', '0');
        this.$element.addClass('dropdown--js');
        this.setLabelText();
        this.$select.on('change', this.setLabelText);
        return this.$element.on('keydown', this.handleKeyDown);
      };

      Dropdown.prototype.handleKeyDown = function(e) {
        if (e.which === 32) {
          return this.$select.focus();
        }
      };

      Dropdown.prototype.setLabelText = function() {
        return this.$label.text(this.$select.find('option:selected').text());
      };

      return Dropdown;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, Dropdown.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.dropdown');
        if (!data) {
          data = new Dropdown(this, options);
          return $this.data('axa.dropdown', data);
        }
      });
    };
    $.fn.dropdown = Plugin;
    $.fn.dropdown.Constructor = Dropdown;
    return $(window).on('load', function() {
      return $('[data-dropdown]').each(function() {
        var $dropdown, data;
        $dropdown = $(this);
        data = $dropdown.data();
        return Plugin.call($dropdown, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Dropzone, Plugin;
    Dropzone = (function() {
      function Dropzone(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.init();
      }

      Dropzone.prototype.init = function() {
        this.$element.bind('dragover', this, function(event) {
          event.preventDefault();
          return event.data.$element.addClass('dropzone__container--dragover');
        });
        this.$element.bind('dragleave', this, function(event) {
          event.preventDefault();
          return event.data.$element.removeClass('dropzone__container--dragover');
        });
        return this.$element.on('drop', this, function(event) {
          event.preventDefault();
          return event.data.$element.removeClass('dropzone__container--dragover');
        });
      };

      return Dropzone;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.dropzone');
        if (!data) {
          data = new Dropzone(this);
          return $this.data('axa.dropzone', data);
        }
      });
    };
    $.fn.dropzone = Plugin;
    $.fn.dropzone.Constructor = Dropzone;
    return $(window).on('load', function() {
      return $('[data-dropzone="dropzone"]').each(function() {
        var $dropzone;
        $dropzone = $(this);
        return Plugin.call($dropzone);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var IE9Spinner, Plugin;
    IE9Spinner = (function() {
      function IE9Spinner(element, options) {
        this.$element = $(element);
        this.$element.addClass('is-fallback-active');
      }

      return IE9Spinner;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        $this = $(this);
        data = $this.data('axa.ie9Spinner');
        if (!data) {
          data = new IE9Spinner(this, options);
          return $this.data('axa.ie9Spinner', data);
        }
      });
    };
    $.fn.ie9Spinner = Plugin;
    $.fn.ie9Spinner.Constructor = IE9Spinner;
    return $(window).on('load', function() {
      var elm, i, len, properties, property;
      elm = document.createElement('div');
      properties = ['animation', 'WebkitAnimation', 'MozAnimation', 'msAnimation', 'OAnimation'];
      for (i = 0, len = properties.length; i < len; i++) {
        property = properties[i];
        if (elm.style[property] != null) {
          return;
        }
      }
      return $('[data-spinner]').each(function() {
        var $spinner;
        $spinner = $(this);
        return Plugin.call($spinner);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Info, Plugin;
    Info = (function() {
      function Info(element, options) {
        var selector;
        this.$element = $(element);
        selector = this.$element.data('target');
        if (selector == null) {
          selector = options.target;
        }
        this.$target = $(selector);
        this.$element.on('click', this, function(event) {
          return event.data.toggle(event);
        });
      }

      Info.prototype.toggle = function() {
        this.$target.slideToggle();
        return this.$element.toggleClass('is-active');
      };

      return Info;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        $this = $(this);
        data = $this.data('axa.info');
        if (!data) {
          data = new Info(this, options);
          return $this.data('axa.info', data);
        }
      });
    };
    $.fn.info = Plugin;
    $.fn.info.Constructor = Info;
    return $(window).on('load', function() {
      return $('[data-info]').each(function() {
        var $info;
        $info = $(this);
        return Plugin.call($info);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var CollapsingMenu, Plugin;
    CollapsingMenu = (function() {
      CollapsingMenu.DEFAULTS = {
        exclusive: false
      };

      function CollapsingMenu(element, options) {
        this.$element = $(element);
        this.options = $.extend({}, CollapsingMenu.DEFAULTS, options);
        this.init();
      }

      CollapsingMenu.prototype.init = function() {
        return this.$element.on('click', '.menu__link', this, function(event) {
          var link, subLevel;
          link = $(event.target);
          subLevel = link.siblings('.menu__level');
          if (subLevel.length > 0) {
            return event.data.toggle(subLevel);
          }
        });
      };

      CollapsingMenu.prototype.toggle = function(toSet) {
        var level, parentLevels, parentLinks, shouldOpen;
        level = this.$element.find(toSet);
        if (!level) {
          throw new Error('Provided level not in menu!');
        }
        parentLinks = level.parentsUntil(this.$element, '.menu__link');
        parentLevels = level.parentsUntil(this.$element, '.menu__level');
        shouldOpen = !level.hasClass('is-open');
        if (shouldOpen && this.options.exclusive) {
          this.$element.find('.menu__level').not(parentLevels).removeClass('is-open').siblings('.menu__link').removeClass('is-active');
        }
        return level.toggleClass('is-open', shouldOpen).siblings('.menu__link').toggleClass('is-active', shouldOpen);
      };

      return CollapsingMenu;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        $this = $(this);
        options = $.extend({}, CollapsingMenu.DEFAULTS, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        data = $this.data('axa.menu');
        if (!data) {
          data = new CollapsingMenu(this, options);
          $this.data('axa.menu', data);
        }
        if (action === 'toggle') {
          return data.toggle(params[1]);
        }
      });
    };
    $.fn.collapsingMenu = Plugin;
    $.fn.collapsingMenu.Constructor = CollapsingMenu;
    return $(window).on('load', function() {
      return $('[data-menu="collapsing"]').each(function() {
        var $menu, data;
        $menu = $(this);
        data = $menu.data();
        return Plugin.call($menu, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, SlidingMenu;
    SlidingMenu = (function() {
      SlidingMenu.DEFAULTS;

      function SlidingMenu(element, options) {
        this.onWindowResize = bind(this.onWindowResize, this);
        this.$element = $(element);
        this.options = $.extend({}, SlidingMenu.DEFAULTS, options);
        this.init();
        this.level(this.$element.children('.menu__level'));
        $(window).on('resize', this.onWindowResize);
      }

      SlidingMenu.prototype.init = function() {
        this.$element.on('click', '.menu__link--back', this, function(event) {
          var currentLevel, link, upperLevel;
          link = $(event.target);
          currentLevel = link.closest('.menu__level');
          upperLevel = currentLevel.parent().closest('.menu__level');
          return event.data.level(upperLevel);
        });
        return this.$element.on('click', '.menu__link', this, function(event) {
          var link, subLevel;
          link = $(event.target);
          subLevel = link.siblings('.menu__level');
          if (subLevel.length > 0) {
            return event.data.level(subLevel);
          }
        });
      };

      SlidingMenu.prototype.onWindowResize = function(e) {
        return this.$element.css('height', this.level().height());
      };

      SlidingMenu.prototype.level = function(toSet) {
        var level, parentLevels, parentLinks;
        if (!toSet) {
          return this.$element.find('.is-current');
        } else {
          this.$element.find('.is-current').removeClass('is-current');
          this.$element.find('.is-active').removeClass('is-active');
          this.$element.find('.menu__level').css('left', '');
          level = this.$element.find(toSet);
          if (!level) {
            throw new Error('Provided level not in menu!');
          }
          this.$element.css('height', level.height());
          parentLevels = level.parentsUntil(this.$element, '.menu__level');
          parentLinks = level.parentsUntil(this.$element, '.menu__link');
          this.$element.children('.menu__level').css('left', (parentLevels.length * -100) + '%');
          level.addClass('is-current');
          level.siblings('.menu__link').addClass('is-active');
          return parentLinks.addClass('is-active');
        }
      };

      return SlidingMenu;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        $this = $(this);
        options = $.extend({}, SlidingMenu.DEFAULTS, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        data = $this.data('axa.menu');
        if (!data) {
          data = new SlidingMenu(this, options);
          $this.data('axa.menu', data);
        }
        if (action === 'level') {
          return data.level(params[1]);
        }
      });
    };
    $.fn.slidingMenu = Plugin;
    $.fn.slidingMenu.Constructor = SlidingMenu;
    return $(window).on('load', function() {
      return $('[data-menu="sliding"]').each(function() {
        var $menu, data;
        $menu = $(this);
        data = $menu.data();
        return Plugin.call($menu, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Modal, Plugin;
    Modal = (function() {
      function Modal(element, options) {
        this.$element = $(element);
      }

      Modal.prototype.toggle = function() {
        if (this.$element.hasClass('is-active')) {
          this.$element.removeClass('is-active');
          return $('body').removeClass('is-modal-open');
        } else {
          this.$element.addClass('is-active');
          return $('body').addClass('is-modal-open');
        }
      };

      return Modal;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.modal');
        if (!data) {
          data = new Modal(this);
          $this.data('axa.modal', data);
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.modal = Plugin;
    $.fn.modal.Constructor = Modal;
    return $(document).on('click.axa.modal.data-api', '[data-modal]', function(e) {
      var $target;
      e.preventDefault();
      $target = $($(e.currentTarget).data('modal'));
      return Plugin.call($target, 'toggle');
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var NotificationPane, Plugin;
    NotificationPane = (function() {
      function NotificationPane(element, options) {
        this.$element = $(element);
        console.log(this.$element);
        this.path = {
          info: this.$element.data('notification-info'),
          success: this.$element.data('notification-success'),
          error: this.$element.data('notification-error')
        };
      }

      NotificationPane.prototype.displayNotification = function(notification) {
        var $content, $icon, $iconContainer, $notification, timeout;
        if (notification == null) {
          return;
        }
        $notification = $('<div class="notifications__item" ></div>');
        $icon = null;
        if (notification.modifier) {
          console.log(notification.modifier);
          console.log(this.path);
          console.log(this.path[notification.modifier]);
          $notification.addClass('notifications__item--' + notification.modifier);
          $icon = '<svg class="icon-svg notifications__item__icon"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="' + this.path[notification.modifier] + '"></use></svg>';
          console.log($icon);
        }
        $iconContainer = $('<div class="notifications__item__icon-container">');
        $iconContainer.append($icon);
        $notification.append($iconContainer);
        $notification.on('click', function() {
          return this.hideNotification($notification);
        });
        $content = $('<div class="notifications__item__content"></div>');
        if (notification.html === true) {
          $content.html(notification.content);
        } else {
          $content.text(notification.content);
        }
        $notification.append($content);
        timeout = 2000;
        if (typeof notification.timeout === "number") {
          timeout = notification.timeout;
        }
        setTimeout(((function(_this) {
          return function() {
            return _this.hideNotification($notification);
          };
        })(this)), timeout);
        return this.$element.append($notification);
      };

      NotificationPane.prototype.hideNotification = function($notification) {
        $notification.addClass('notifications__item--fade-out');
        return setTimeout((function() {
          return $notification.remove();
        }), 500);
      };

      return NotificationPane;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.notification');
        if (!data) {
          data = new NotificationPane(this);
          $this.data('axa.notification', data);
        }
        if (typeof option === 'object') {
          data.displayNotification(option);
        }
        if (typeof option === 'string') {
          return data.displayNotification({
            content: option
          });
        }
      });
    };
    $.fn.notification = Plugin;
    $.fn.notification.Constructor = NotificationPane;
    return $(document).on('click.axa.notification.data-api', '[data-notification]', function(e) {
      var $target, $this;
      e.preventDefault();
      $this = $(this);
      $target = $($this.data('notification'));
      return Plugin.call($target, {
        content: $this.data('notification-content'),
        modifier: $this.data('notification-modifier')
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, Popover;
    Popover = (function() {
      function Popover(element, options) {
        this.position = bind(this.position, this);
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.$target = $(this.$element.data('popover'));
        this.$closeIcon = this.$target.find('.popover__close');
        this.isOpen = false;
        this.$element.on('click', this, this.toggle);
        this.$closeIcon.on('click', this, this.toggle);
        this.position();
        $(window).on('resize', this.position);
      }

      Popover.prototype.toggle = function(event) {
        event.data.isOpen = !event.data.isOpen;
        event.data.position();
        return event.data.$target.toggleClass('is-active');
      };

      Popover.prototype.position = function() {
        var $box, $tail, isSmall, maxOffsetLeft, maxOffsetTop, offset, tailClass, tailOffset;
        $box = this.$target.find('.popover__box');
        $tail = this.$target.find('.popover__tail');
        isSmall = false;
        if (window.matchMedia != null) {
          isSmall = !window.matchMedia('(min-width: 768px)').matches;
        } else {
          isSmall = $(window).outerWidth() < 768;
        }
        if (isSmall) {
          if (this.isOpen) {
            $('body').addClass('is-modal-open');
          } else {
            $('body').removeClass('is-modal-open');
          }
          return $box.css({
            top: 0,
            left: 0
          });
        } else {
          $('body').removeClass('is-modal-open');
          maxOffsetTop = $(document).height() - $box.outerHeight();
          maxOffsetLeft = $(document).width() - $box.outerWidth() - 20;
          offset = {
            top: 0,
            left: 0
          };
          offset.top = this.$element.offset().top + this.$element.outerHeight() + 20;
          offset.left = this.$element.offset().left;
          if (offset.left > maxOffsetLeft) {
            offset.left = maxOffsetLeft;
          }
          $tail.removeClass('popover__tail--top popover__tail--bottom');
          tailOffset = {
            top: 0,
            left: 0
          };
          tailOffset.top = this.$element.offset().top + this.$element.outerHeight() - 20;
          tailOffset.left = this.$element.offset().left + this.$element.outerWidth() / 2 - 20;
          tailClass = 'popover__tail--top';
          if (offset.top > maxOffsetTop) {
            offset.top = this.$element.offset().top - $box.outerHeight() - 20;
            tailOffset.top = this.$element.offset().top - 20;
            tailClass = 'popover__tail--bottom';
          }
          $box.offset(offset);
          $tail.addClass(tailClass);
          return $tail.offset(tailOffset);
        }
      };

      return Popover;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        $this = $(this);
        data = $this.data('axa.popover');
        if (!data) {
          data = new Popover(this, options);
          return $this.data('axa.popover', data);
        }
      });
    };
    $.fn.popover = Plugin;
    $.fn.popover.Constructor = Popover;
    return $(window).on('load', function() {
      return $('[data-popover]').each(function() {
        var $popover;
        $popover = $(this);
        return Plugin.call($popover);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, SegmentedControl;
    SegmentedControl = (function() {
      SegmentedControl.DEFAULTS;

      function SegmentedControl(element, options) {
        this.setRadioState = bind(this.setRadioState, this);
        this.handleKeyDown = bind(this.handleKeyDown, this);
        this.handleKeyUp = bind(this.handleKeyUp, this);
        var disabled;
        this.$element = $(element);
        disabled = this.$element.is('[disabled=disabled]');
        this.$radios = this.$element.find('.segmented-control__item__radio');
        this.$radios.each(function(index, element) {
          var $radio;
          $radio = $(element);
          if (disabled) {
            $radio.prop('disabled', 'disabled');
          }
          return $radio.data('item.element', $radio.closest('.segmented-control__item'));
        });
        this.options = $.extend({}, SegmentedControl.DEFAULTS, options);
        this.init();
      }

      SegmentedControl.prototype.init = function() {
        this.$radios.prop('tabindex', '-1');
        this.$element.prop('tabindex', '0');
        this.$element.addClass('segmented-control--js');
        this.setRadioState();
        this.$radios.on('change', this.setRadioState);
        this.$element.on('keyup', this.handleKeyUp);
        this.$element.on('keydown', this.handleKeyDown);
        this.stackControlsIfNeeded();
        return $('window').on('resize', this.stackControlsIfNeeded);
      };

      SegmentedControl.prototype.stackControlsIfNeeded = function() {
        this.$element.removeClass('segmented-control--stacked');
        if (this.$element.outerWidth() >= this.$element.parent().innerWidth()) {
          return this.$element.addClass('segmented-control--stacked');
        }
      };

      SegmentedControl.prototype.handleKeyUp = function(e) {
        var $first;
        if (e.which === 32) {
          e.preventDefault();
          if (this.$radios.filter(':checked').length === 0) {
            $first = $(this.$radios[0]);
            $first.prop('checked', true);
            return $first.change();
          }
        }
      };

      SegmentedControl.prototype.handleKeyDown = function(e) {
        var $checked, $first, $next, $previous;
        switch (e.which) {
          case 32:
            return e.preventDefault();
          case 37:
          case 38:
            e.preventDefault();
            $checked = $(this.$radios.filter(':checked'));
            if ($checked.length !== 0) {
              $previous = $(this.$radios[this.$radios.index($checked) - 1]);
              if (($previous != null) && $previous.length !== 0) {
                $previous.prop('checked', true);
                return $previous.change();
              }
            }
            break;
          case 39:
          case 40:
            e.preventDefault();
            $checked = $(this.$radios.filter(':checked'));
            if ($checked.length === 0) {
              $first = $(this.$radios[1]);
              if (($first != null) & $first.length !== 0) {
                $first.prop('checked', true);
                return $first.change();
              }
            } else {
              $next = $(this.$radios[this.$radios.index($checked) + 1]);
              if (($next != null) && $next.length !== 0) {
                $next.prop('checked', true);
                return $next.change();
              }
            }
        }
      };

      SegmentedControl.prototype.setRadioState = function() {
        return this.$radios.each(function(index, element) {
          var $item, $radio;
          $radio = $(element);
          $item = $radio.data('item.element');
          if ($radio.is(':checked')) {
            return $item.addClass('is-active');
          } else {
            return $item.removeClass('is-active');
          }
        });
      };

      return SegmentedControl;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, SegmentedControl.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.segmentedControl');
        if (!data) {
          data = new SegmentedControl(this, options);
          return $this.data('axa.segmentedControl', data);
        }
      });
    };
    $.fn.segmentedControl = Plugin;
    $.fn.segmentedControl.Constructor = SegmentedControl;
    return $(window).on('load', function() {
      return $('[data-segmented-control]').each(function() {
        var $segmentedControl, data;
        $segmentedControl = $(this);
        data = $segmentedControl.data();
        return Plugin.call($segmentedControl, data);
      });
    });
  })(jQuery);

}).call(this);


(function() {
  (function($) {
    var Plugin, Site;
    Site = (function() {
      Site.DEFAULTS = {
        mask: false
      };

      function Site(element, options) {
        this.$element = $(element);
        this.$page = this.$element.find('.site__page');
        this.$menu = this.$element.find('.site__mobile-menu');
        this.options = $.extend({}, Site.DEFAULTS, options);
        this.$element.on('click', '.site__page.is-masked', this, function(event) {
          return event.data.hideMenu();
        });
      }

      Site.prototype.toggleMenu = function(show) {
        if (show == null) {
          show = !this.$page.hasClass('is-pushed');
        }
        this.$element.toggleClass('is-mobile-nav-open', show);
        this.$page.toggleClass('is-pushed', show);
        if (this.options.mask) {
          this.$page.toggleClass('is-masked', show);
        }
        return this.$menu.toggleClass('is-visible', show);
      };

      Site.prototype.showMenu = function() {
        return this.toggleMenu(true);
      };

      Site.prototype.hideMenu = function() {
        return this.toggleMenu(false);
      };

      return Site;

    })();
    Plugin = function(option) {
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        data = $this.data('axa.site');
        if (!data) {
          options = typeof option === 'object' && option;
          options = options || {};
          $.extend(options, $this.data());
          data = new Site(this, options);
          $this.data('axa.site', data);
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.site = Plugin;
    $.fn.site.Constructor = Site;
    return ($(document)).on('click.axa.site.data-api', '[data-toggle="site-menu"]', function(e) {
      var $target, $this, href;
      $this = $(this);
      href = $this.attr('href');
      $target = $($this.attr('data-target') || (href && href.replace(/.*(?=#[^\s]+$)/, '')));
      if ($this.is('a')) {
        e.preventDefault;
      }
      return Plugin.call($target, 'toggleMenu');
    });
  })(jQuery);

}).call(this);


//# sourceMappingURL=axa-wsg.jquery.all.js.map