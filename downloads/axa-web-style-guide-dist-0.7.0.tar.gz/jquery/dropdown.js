(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Dropdown, Plugin;
    Dropdown = (function() {
      Dropdown.DEFAULTS;

      function Dropdown(element, options) {
        this.setLabelText = bind(this.setLabelText, this);
        this.handleKeyDown = bind(this.handleKeyDown, this);
        this.$element = $(element);
        this.$label = this.$element.find('.dropdown__label__text');
        this.$select = this.$element.find('.dropdown__select');
        this.options = $.extend({}, Dropdown.DEFAULTS, options);
        this.init();
      }

      Dropdown.prototype.init = function() {
        this.$select.attr('tabindex', '-1');
        this.$element.attr('tabindex', '0');
        this.$element.addClass('dropdown--js');
        this.setLabelText();
        this.$select.on('change', this.setLabelText);
        return this.$element.on('keydown', this.handleKeyDown);
      };

      Dropdown.prototype.handleKeyDown = function(e) {
        if (e.which === 32) {
          return this.$select.focus();
        }
      };

      Dropdown.prototype.setLabelText = function() {
        return this.$label.text(this.$select.find('option:selected').text());
      };

      return Dropdown;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, Dropdown.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.dropdown');
        if (!data) {
          data = new Dropdown(this, options);
          return $this.data('axa.dropdown', data);
        }
      });
    };
    $.fn.dropdown = Plugin;
    $.fn.dropdown.Constructor = Dropdown;
    return $(window).on('load', function() {
      return $('[data-dropdown]').each(function() {
        var $dropdown, data;
        $dropdown = $(this);
        data = $dropdown.data();
        return Plugin.call($dropdown, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=dropdown.js.map