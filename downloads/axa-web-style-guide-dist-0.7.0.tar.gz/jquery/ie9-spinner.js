(function() {
  (function($) {
    var IE9Spinner, Plugin;
    IE9Spinner = (function() {
      function IE9Spinner(element, options) {
        this.$element = $(element);
        this.$element.addClass('is-fallback-active');
      }

      return IE9Spinner;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        $this = $(this);
        data = $this.data('axa.ie9Spinner');
        if (!data) {
          data = new IE9Spinner(this, options);
          return $this.data('axa.ie9Spinner', data);
        }
      });
    };
    $.fn.ie9Spinner = Plugin;
    $.fn.ie9Spinner.Constructor = IE9Spinner;
    return $(window).on('load', function() {
      var elm, i, len, properties, property;
      elm = document.createElement('div');
      properties = ['animation', 'WebkitAnimation', 'MozAnimation', 'msAnimation', 'OAnimation'];
      for (i = 0, len = properties.length; i < len; i++) {
        property = properties[i];
        if (elm.style[property] != null) {
          return;
        }
      }
      return $('[data-spinner]').each(function() {
        var $spinner;
        $spinner = $(this);
        return Plugin.call($spinner);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=ie9-spinner.js.map