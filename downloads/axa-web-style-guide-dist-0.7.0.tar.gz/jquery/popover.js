(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, Popover;
    Popover = (function() {
      function Popover(element, options) {
        this.position = bind(this.position, this);
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.$target = $(this.$element.data('popover'));
        this.$closeIcon = this.$target.find('.popover__close');
        this.isOpen = false;
        this.$element.on('click', this, this.toggle);
        this.$closeIcon.on('click', this, this.toggle);
        this.position();
        $(window).on('resize', this.position);
      }

      Popover.prototype.toggle = function(event) {
        event.data.isOpen = !event.data.isOpen;
        event.data.position();
        return event.data.$target.toggleClass('is-active');
      };

      Popover.prototype.position = function() {
        var $box, $tail, isSmall, maxOffsetLeft, maxOffsetTop, offset, tailClass, tailOffset;
        $box = this.$target.find('.popover__box');
        $tail = this.$target.find('.popover__tail');
        isSmall = false;
        if (window.matchMedia != null) {
          isSmall = !window.matchMedia('(min-width: 768px)').matches;
        } else {
          isSmall = $(window).outerWidth() < 768;
        }
        if (isSmall) {
          if (this.isOpen) {
            $('body').addClass('is-modal-open');
          } else {
            $('body').removeClass('is-modal-open');
          }
          return $box.css({
            top: 0,
            left: 0
          });
        } else {
          $('body').removeClass('is-modal-open');
          maxOffsetTop = $(document).height() - $box.outerHeight();
          maxOffsetLeft = $(document).width() - $box.outerWidth() - 20;
          offset = {
            top: 0,
            left: 0
          };
          offset.top = this.$element.offset().top + this.$element.outerHeight() + 20;
          offset.left = this.$element.offset().left;
          if (offset.left > maxOffsetLeft) {
            offset.left = maxOffsetLeft;
          }
          $tail.removeClass('popover__tail--top popover__tail--bottom');
          tailOffset = {
            top: 0,
            left: 0
          };
          tailOffset.top = this.$element.offset().top + this.$element.outerHeight() - 20;
          tailOffset.left = this.$element.offset().left + this.$element.outerWidth() / 2 - 20;
          tailClass = 'popover__tail--top';
          if (offset.top > maxOffsetTop) {
            offset.top = this.$element.offset().top - $box.outerHeight() - 20;
            tailOffset.top = this.$element.offset().top - 20;
            tailClass = 'popover__tail--bottom';
          }
          $box.offset(offset);
          $tail.addClass(tailClass);
          return $tail.offset(tailOffset);
        }
      };

      return Popover;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        $this = $(this);
        data = $this.data('axa.popover');
        if (!data) {
          data = new Popover(this, options);
          return $this.data('axa.popover', data);
        }
      });
    };
    $.fn.popover = Plugin;
    $.fn.popover.Constructor = Popover;
    return $(window).on('load', function() {
      return $('[data-popover]').each(function() {
        var $popover;
        $popover = $(this);
        return Plugin.call($popover);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=popover.js.map