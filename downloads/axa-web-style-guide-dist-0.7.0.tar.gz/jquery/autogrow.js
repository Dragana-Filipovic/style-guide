(function() {
  (function($) {
    var Autogrow, Plugin;
    Autogrow = (function() {
      function Autogrow(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.init();
      }

      Autogrow.prototype.init = function() {
        this.minHeight = this.$element.height();
        this.shadow = $('<div></div>');
        this.shadow.css({
          position: 'absolute',
          top: -10000,
          left: -10000,
          width: this.$element.width(),
          'font-size': this.$element.css('font-size'),
          'font-family': this.$element.css('font-family'),
          'font-weight': this.$element.css('font-weight'),
          'line-height': this.$element.css('line-height'),
          resize: 'none',
          'word-wrap': 'break-word'
        });
        this.shadow.appendTo(document.body);
        this.$element.on('change keyup keydown', this, function(event) {
          return event.data.update(event);
        });
        return $(window).resize(this.update);
      };

      Autogrow.prototype.update = function(event) {
        var newHeight, val;
        ({
          times: function(string, number) {
            var r;
            r = '';
            while (num -= 1) {
              r += string;
            }
            return r;
          }
        });
        if (this.element) {
          val = this.element.value.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&/g, '&amp;').replace(/\n$/, '<br/>&nbsp;').replace(/\n/g, '<br/>').replace(/\s{2,}/g, function(space) {
            return times('&nbsp;', space.length - 1) + ' ';
          });
          if ((event != null) && (event.data != null) && event.data.event === 'keydown' && event.keyCode === 13) {
            val += '<br />';
          }
          this.shadow.css('width', this.$element.width());
          this.shadow.html(val);
          newHeight = Math.max(this.shadow.height(), this.minHeight);
          return this.$element.height(newHeight);
        }
      };

      return Autogrow;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.autogrow');
        if (!data) {
          data = new Autogrow(this);
          return $this.data('axa.autogrow', data);
        }
      });
    };
    $.fn.autogrow = Plugin;
    $.fn.autogrow.Constructor = Autogrow;
    return $(window).on('load', function() {
      return $('[data-autogrow="autogrow"]').each(function() {
        var $autogrow;
        $autogrow = $(this);
        return Plugin.call($autogrow);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=autogrow.js.map