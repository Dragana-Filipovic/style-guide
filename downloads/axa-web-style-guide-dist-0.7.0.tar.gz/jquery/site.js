(function() {
  (function($) {
    var Plugin, Site;
    Site = (function() {
      Site.DEFAULTS = {
        mask: false
      };

      function Site(element, options) {
        this.$element = $(element);
        this.$page = this.$element.find('.site__page');
        this.$menu = this.$element.find('.site__mobile-menu');
        this.options = $.extend({}, Site.DEFAULTS, options);
        this.$element.on('click', '.site__page.is-masked', this, function(event) {
          return event.data.hideMenu();
        });
      }

      Site.prototype.toggleMenu = function(show) {
        if (show == null) {
          show = !this.$page.hasClass('is-pushed');
        }
        this.$element.toggleClass('is-mobile-nav-open', show);
        this.$page.toggleClass('is-pushed', show);
        if (this.options.mask) {
          this.$page.toggleClass('is-masked', show);
        }
        return this.$menu.toggleClass('is-visible', show);
      };

      Site.prototype.showMenu = function() {
        return this.toggleMenu(true);
      };

      Site.prototype.hideMenu = function() {
        return this.toggleMenu(false);
      };

      return Site;

    })();
    Plugin = function(option) {
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        data = $this.data('axa.site');
        if (!data) {
          options = typeof option === 'object' && option;
          options = options || {};
          $.extend(options, $this.data());
          data = new Site(this, options);
          $this.data('axa.site', data);
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.site = Plugin;
    $.fn.site.Constructor = Site;
    return ($(document)).on('click.axa.site.data-api', '[data-toggle="site-menu"]', function(e) {
      var $target, $this, href;
      $this = $(this);
      href = $this.attr('href');
      $target = $($this.attr('data-target') || (href && href.replace(/.*(?=#[^\s]+$)/, '')));
      if ($this.is('a')) {
        e.preventDefault;
      }
      return Plugin.call($target, 'toggleMenu');
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=site.js.map