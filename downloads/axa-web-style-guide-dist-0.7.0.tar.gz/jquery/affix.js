(function() {
  (function($) {
    var Affix, Plugin;
    Affix = (function() {
      Affix.VERSION = '1.0.0';

      Affix.RESET = 'is-affixed is-affixed-top is-affixed-bottom';

      Affix.DEFAULTS = {
        offset: 0,
        target: window
      };

      function Affix(element, options) {
        this.options = $.extend({}, Affix.DEFAULTS, options);
        this.$target = $(this.options.target).on('scroll.axa.affix.data-api', $.proxy(this.checkPosition, this)).on('click.axa.affix.data-api', $.proxy(this.checkPositionWithEventLoop, this));
        this.$element = $(element);
        this.affixed = null;
        this.unpin = null;
        this.pinnedOffset = null;
        this.checkPosition();
      }

      Affix.prototype.getState = function(scrollHeight, height, offsetTop, offsetBottom) {
        var colliderHeight, colliderTop, initializing, position, scrollTop, targetHeight;
        scrollTop = this.$target.scrollTop();
        position = this.$element.offset();
        targetHeight = this.$target.height();
        if (offsetTop !== null && this.affixed === 'top') {
          if (scrollTop < offsetTop) {
            return 'top';
          } else {
            return false;
          }
        }
        if (this.affixed === 'bottom') {
          if (offsetTop !== null) {
            if (scrollTop + this.unpin <= position.top) {
              return false;
            } else {
              return 'bottom';
            }
          }
          if (scrollTop + targetHeight <= scrollHeight - offsetBottom) {
            return false;
          } else {
            return 'bottom';
          }
        }
        initializing = this.affixed === null;
        colliderTop = initializing ? scrollTop : position.top;
        colliderHeight = initializing ? targetHeight : height;
        if (offsetTop !== null && colliderTop <= offsetTop) {
          return 'top';
        }
        if (offsetBottom !== null && (colliderTop + colliderHeight >= scrollHeight - offsetBottom)) {
          return 'bottom';
        }
        return false;
      };

      Affix.prototype.getPinnedOffset = function() {
        var position, scrollTop;
        if (this.pinnedOffset) {
          return this.pinnedOffset;
        }
        this.$element.removeClass(Affix.RESET).addClass('is-affixed');
        scrollTop = this.$target.scrollTop();
        position = this.$element.offset();
        return (this.pinnedOffset = position.top - scrollTop);
      };

      Affix.prototype.checkPositionWithEventLoop = function() {
        return setTimeout($.proxy(this.checkPosition, this), 1);
      };

      Affix.prototype.checkPosition = function() {
        var affix, affixType, e, height, offset, offsetBottom, offsetTop, scrollHeight;
        if (!this.$element.is(':visible')) {
          return;
        }
        height = this.$element.height();
        offset = this.options.offset;
        offsetTop = offset.top;
        offsetBottom = offset.bottom;
        scrollHeight = $('body').height();
        if (typeof offset !== 'object') {
          offsetBottom = offsetTop = offset;
        }
        if (typeof offsetTop === 'function') {
          offsetTop = offset.top(this.$element);
        }
        if (typeof offsetBottom === 'function') {
          offsetBottom = offset.bottom(this.$element);
        }
        affix = this.getState(scrollHeight, height, offsetTop, offsetBottom);
        if (this.affixed !== affix) {
          if (this.unpin !== null) {
            this.$element.css('top', '');
          }
          affixType = 'is-affixed' + (affix ? '-' + affix : '');
          e = $.Event(affixType + '.axa.affix');
          this.$element.trigger(e);
          if (e.isDefaultPrevented()) {
            return;
          }
          this.affixed = affix;
          if (affix === 'bottom') {
            this.unpin = this.getPinnedOffset();
          } else {
            this.unpin = null;
          }
          this.$element.removeClass(Affix.RESET).addClass(affixType).trigger(affixType.replace('affix', 'affixed') + '.axa.affix');
        }
        if (affix === 'bottom') {
          return this.$element.offset({
            top: scrollHeight - height - offsetBottom
          });
        }
      };

      return Affix;

    })();
    Plugin = function(option) {
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        data = $this.data('axa.affix');
        options = typeof option === 'object' && option;
        if (!data) {
          $this.data('axa.affix', (data = new Affix(this, options)));
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.affix = Plugin;
    $.fn.affix.Constructor = Affix;
    return $(window).on('load', function() {
      return $('[data-spy="affix"]').each(function() {
        var $spy, data;
        $spy = $(this);
        data = $spy.data();
        data.offset = data.offset || {};
        if (data.offsetBottom !== null) {
          data.offset.bottom = data.offsetBottom;
        }
        if (data.offsetTop !== null) {
          data.offset.top = data.offsetTop;
        }
        return Plugin.call($spy, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=affix.js.map