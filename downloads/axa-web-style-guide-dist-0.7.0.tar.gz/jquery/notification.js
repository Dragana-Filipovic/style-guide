(function() {
  (function($) {
    var NotificationPane, Plugin;
    NotificationPane = (function() {
      function NotificationPane(element, options) {
        this.$element = $(element);
        console.log(this.$element);
        this.path = {
          info: this.$element.data('notification-info'),
          success: this.$element.data('notification-success'),
          error: this.$element.data('notification-error')
        };
      }

      NotificationPane.prototype.displayNotification = function(notification) {
        var $content, $icon, $iconContainer, $notification, timeout;
        if (notification == null) {
          return;
        }
        $notification = $('<div class="notifications__item" ></div>');
        $icon = null;
        if (notification.modifier) {
          console.log(notification.modifier);
          console.log(this.path);
          console.log(this.path[notification.modifier]);
          $notification.addClass('notifications__item--' + notification.modifier);
          $icon = '<svg class="icon-svg notifications__item__icon"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="' + this.path[notification.modifier] + '"></use></svg>';
          console.log($icon);
        }
        $iconContainer = $('<div class="notifications__item__icon-container">');
        $iconContainer.append($icon);
        $notification.append($iconContainer);
        $notification.on('click', function() {
          return this.hideNotification($notification);
        });
        $content = $('<div class="notifications__item__content"></div>');
        if (notification.html === true) {
          $content.html(notification.content);
        } else {
          $content.text(notification.content);
        }
        $notification.append($content);
        timeout = 2000;
        if (typeof notification.timeout === "number") {
          timeout = notification.timeout;
        }
        setTimeout(((function(_this) {
          return function() {
            return _this.hideNotification($notification);
          };
        })(this)), timeout);
        return this.$element.append($notification);
      };

      NotificationPane.prototype.hideNotification = function($notification) {
        $notification.addClass('notifications__item--fade-out');
        return setTimeout((function() {
          return $notification.remove();
        }), 500);
      };

      return NotificationPane;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.notification');
        if (!data) {
          data = new NotificationPane(this);
          $this.data('axa.notification', data);
        }
        if (typeof option === 'object') {
          data.displayNotification(option);
        }
        if (typeof option === 'string') {
          return data.displayNotification({
            content: option
          });
        }
      });
    };
    $.fn.notification = Plugin;
    $.fn.notification.Constructor = NotificationPane;
    return $(document).on('click.axa.notification.data-api', '[data-notification]', function(e) {
      var $target, $this;
      e.preventDefault();
      $this = $(this);
      $target = $($this.data('notification'));
      return Plugin.call($target, {
        content: $this.data('notification-content'),
        modifier: $this.data('notification-modifier')
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=notification.js.map