(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, SlidingMenu;
    SlidingMenu = (function() {
      SlidingMenu.DEFAULTS;

      function SlidingMenu(element, options) {
        this.onWindowResize = bind(this.onWindowResize, this);
        this.$element = $(element);
        this.options = $.extend({}, SlidingMenu.DEFAULTS, options);
        this.init();
        this.level(this.$element.children('.menu__level'));
        $(window).on('resize', this.onWindowResize);
      }

      SlidingMenu.prototype.init = function() {
        this.$element.on('click', '.menu__link--back', this, function(event) {
          var currentLevel, link, upperLevel;
          link = $(event.target);
          currentLevel = link.closest('.menu__level');
          upperLevel = currentLevel.parent().closest('.menu__level');
          return event.data.level(upperLevel);
        });
        return this.$element.on('click', '.menu__link', this, function(event) {
          var link, subLevel;
          link = $(event.target);
          subLevel = link.siblings('.menu__level');
          if (subLevel.length > 0) {
            return event.data.level(subLevel);
          }
        });
      };

      SlidingMenu.prototype.onWindowResize = function(e) {
        return this.$element.css('height', this.level().height());
      };

      SlidingMenu.prototype.level = function(toSet) {
        var level, parentLevels, parentLinks;
        if (!toSet) {
          return this.$element.find('.is-current');
        } else {
          this.$element.find('.is-current').removeClass('is-current');
          this.$element.find('.is-active').removeClass('is-active');
          this.$element.find('.menu__level').css('left', '');
          level = this.$element.find(toSet);
          if (!level) {
            throw new Error('Provided level not in menu!');
          }
          this.$element.css('height', level.height());
          parentLevels = level.parentsUntil(this.$element, '.menu__level');
          parentLinks = level.parentsUntil(this.$element, '.menu__link');
          this.$element.children('.menu__level').css('left', (parentLevels.length * -100) + '%');
          level.addClass('is-current');
          level.siblings('.menu__link').addClass('is-active');
          return parentLinks.addClass('is-active');
        }
      };

      return SlidingMenu;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        $this = $(this);
        options = $.extend({}, SlidingMenu.DEFAULTS, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        data = $this.data('axa.menu');
        if (!data) {
          data = new SlidingMenu(this, options);
          $this.data('axa.menu', data);
        }
        if (action === 'level') {
          return data.level(params[1]);
        }
      });
    };
    $.fn.slidingMenu = Plugin;
    $.fn.slidingMenu.Constructor = SlidingMenu;
    return $(window).on('load', function() {
      return $('[data-menu="sliding"]').each(function() {
        var $menu, data;
        $menu = $(this);
        data = $menu.data();
        return Plugin.call($menu, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=menu-sliding.js.map