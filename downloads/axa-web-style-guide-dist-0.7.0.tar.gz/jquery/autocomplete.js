(function() {
  (function($) {
    var Autocomplete, Plugin;
    Autocomplete = (function() {
      function Autocomplete(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.filtered = this.options.source;
        if (this.filtered == null) {
          this.filtered = [];
        }
        this.value = '';
        this.isMouseOver = false;
        this.$dropdown = $('<div class="autocomplete__suggestions"></div>');
        this.$dropdown.hide();
        this.$element.after(this.$dropdown);
        this.$element.on('keyup', this, function(event) {
          return event.data.filter(event);
        });
        this.$element.on('blur', this, function(event) {
          if (!event.data.isMouseOver) {
            return event.data.$dropdown.hide();
          }
        });
      }

      Autocomplete.prototype.filter = function(event) {
        var i, len, ref, text;
        if (this.value !== this.element.value) {
          this.value = this.element.value;
          this.filtered = (function() {
            var i, len, ref, results;
            ref = this.options.source;
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
              text = ref[i];
              if (text.indexOf(this.value) > -1) {
                results.push(text);
              }
            }
            return results;
          }).call(this);
          this.$dropdown.empty();
          ref = this.filtered;
          for (i = 0, len = ref.length; i < len; i++) {
            text = ref[i];
            this.$dropdown.append(this.createItem(text));
          }
          return this.$dropdown.show();
        }
      };

      Autocomplete.prototype.createItem = function(text) {
        var item;
        item = $('<div class="autocomplete__suggestions__item">' + text + '</div>');
        item.on('mouseover', this, function(event) {
          event.data.isMouseOver = true;
          return $(event.target).addClass('autocomplete__suggestions__item--selected');
        });
        item.on('mouseout', this, function(event) {
          event.data.isMouseOver = false;
          return $(event.target).removeClass('autocomplete__suggestions__item--selected');
        });
        item.on('click', this, function(event) {
          return event.data.selectItem(event);
        });
        return item;
      };

      Autocomplete.prototype.selectItem = function(event) {
        this.element.value = event.target.textContent;
        return this.$dropdown.hide();
      };

      return Autocomplete;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        $this = $(this);
        data = $this.data('axa.autocomplete');
        if (!data) {
          data = new Autocomplete(this, options);
          return $this.data('axa.autocomplete', data);
        }
      });
    };
    $.fn.autocomplete = Plugin;
    $.fn.autocomplete.Constructor = Autocomplete;
    return $(window).on('load', function() {
      return $('[data-autocomplete]').each(function() {
        var $autocomplete;
        $autocomplete = $(this);
        return Plugin.call($autocomplete);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=autocomplete.js.map