(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Checkbox, Plugin;
    Checkbox = (function() {
      Checkbox.DEFAULTS;

      function Checkbox(element, options) {
        this.setCheckboxState = bind(this.setCheckboxState, this);
        this.handleKeyUp = bind(this.handleKeyUp, this);
        this.$element = $(element);
        this.$checkbox = this.$element.find('.checkbox__checkbox');
        this.$label = this.$element.find('.checkbox__label');
        this.options = $.extend({}, Checkbox.DEFAULTS, options);
        this.init();
      }

      Checkbox.prototype.init = function() {
        this.$checkbox.attr('tabindex', '-1');
        this.$label.attr('tabindex', '0');
        this.$element.addClass('checkbox--js');
        this.setCheckboxState();
        this.$checkbox.on('change', this.setCheckboxState);
        return this.$label.on('keyup', this.handleKeyUp);
      };

      Checkbox.prototype.handleKeyUp = function(e) {
        if (e.which === 32) {
          e.preventDefault();
          this.$checkbox.prop('checked', !(this.$checkbox.is(':checked')));
          return this.$checkbox.change();
        }
      };

      Checkbox.prototype.setCheckboxState = function() {
        if (this.$checkbox.is(':checked')) {
          return this.$element.addClass('is-active');
        } else {
          return this.$element.removeClass('is-active');
        }
      };

      return Checkbox;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, Checkbox.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.checkbox');
        if (!data) {
          data = new Checkbox(this, options);
          return $this.data('axa.checkbox', data);
        }
      });
    };
    $.fn.checkbox = Plugin;
    $.fn.checkbox.Constructor = Checkbox;
    return $(window).on('load', function() {
      return $('[data-checkbox]').each(function() {
        var $checkbox, data;
        $checkbox = $(this);
        data = $checkbox.data();
        return Plugin.call($checkbox, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=checkbox.js.map