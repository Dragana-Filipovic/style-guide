(function() {
  (function($) {
    var Modal, Plugin;
    Modal = (function() {
      function Modal(element, options) {
        this.$element = $(element);
      }

      Modal.prototype.toggle = function() {
        if (this.$element.hasClass('is-active')) {
          this.$element.removeClass('is-active');
          return $('body').removeClass('is-modal-open');
        } else {
          this.$element.addClass('is-active');
          return $('body').addClass('is-modal-open');
        }
      };

      return Modal;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.modal');
        if (!data) {
          data = new Modal(this);
          $this.data('axa.modal', data);
        }
        if (typeof option === 'string') {
          return data[option]();
        }
      });
    };
    $.fn.modal = Plugin;
    $.fn.modal.Constructor = Modal;
    return $(document).on('click.axa.modal.data-api', '[data-modal]', function(e) {
      var $target;
      e.preventDefault();
      $target = $($(e.currentTarget).data('modal'));
      return Plugin.call($target, 'toggle');
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=modal.js.map