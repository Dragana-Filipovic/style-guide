(function() {
  (function($) {
    var CollapsingMenu, Plugin;
    CollapsingMenu = (function() {
      CollapsingMenu.DEFAULTS = {
        exclusive: false
      };

      function CollapsingMenu(element, options) {
        this.$element = $(element);
        this.options = $.extend({}, CollapsingMenu.DEFAULTS, options);
        this.init();
      }

      CollapsingMenu.prototype.init = function() {
        return this.$element.on('click', '.menu__link', this, function(event) {
          var link, subLevel;
          link = $(event.target);
          subLevel = link.siblings('.menu__level');
          if (subLevel.length > 0) {
            return event.data.toggle(subLevel);
          }
        });
      };

      CollapsingMenu.prototype.toggle = function(toSet) {
        var level, parentLevels, parentLinks, shouldOpen;
        level = this.$element.find(toSet);
        if (!level) {
          throw new Error('Provided level not in menu!');
        }
        parentLinks = level.parentsUntil(this.$element, '.menu__link');
        parentLevels = level.parentsUntil(this.$element, '.menu__level');
        shouldOpen = !level.hasClass('is-open');
        if (shouldOpen && this.options.exclusive) {
          this.$element.find('.menu__level').not(parentLevels).removeClass('is-open').siblings('.menu__link').removeClass('is-active');
        }
        return level.toggleClass('is-open', shouldOpen).siblings('.menu__link').toggleClass('is-active', shouldOpen);
      };

      return CollapsingMenu;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        $this = $(this);
        options = $.extend({}, CollapsingMenu.DEFAULTS, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        data = $this.data('axa.menu');
        if (!data) {
          data = new CollapsingMenu(this, options);
          $this.data('axa.menu', data);
        }
        if (action === 'toggle') {
          return data.toggle(params[1]);
        }
      });
    };
    $.fn.collapsingMenu = Plugin;
    $.fn.collapsingMenu.Constructor = CollapsingMenu;
    return $(window).on('load', function() {
      return $('[data-menu="collapsing"]').each(function() {
        var $menu, data;
        $menu = $(this);
        data = $menu.data();
        return Plugin.call($menu, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=menu-collapsing.js.map