(function() {
  'use strict';

  angular.module('axa-wsg.datepicker', []);

})();

/* Copyright AXA Versicherungen AG 2015 */
