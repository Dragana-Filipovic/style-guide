(function() {
  'use strict';

  angular.module('axa-wsg', [
    'axa-wsg.datepicker'
  ]);

})();

/* Copyright AXA Versicherungen AG 2015 */
