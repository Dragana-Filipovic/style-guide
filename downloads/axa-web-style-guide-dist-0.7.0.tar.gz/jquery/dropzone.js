(function() {
  (function($) {
    var Dropzone, Plugin;
    Dropzone = (function() {
      function Dropzone(element, options) {
        this.element = element;
        this.$element = $(element);
        this.options = $.extend({}, options);
        this.init();
      }

      Dropzone.prototype.init = function() {
        this.$element.bind('dragover', this, function(event) {
          event.preventDefault();
          return event.data.$element.addClass('dropzone__container--dragover');
        });
        this.$element.bind('dragleave', this, function(event) {
          event.preventDefault();
          return event.data.$element.removeClass('dropzone__container--dragover');
        });
        return this.$element.on('drop', this, function(event) {
          event.preventDefault();
          return event.data.$element.removeClass('dropzone__container--dragover');
        });
      };

      return Dropzone;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data;
        $this = $(this);
        data = $this.data('axa.dropzone');
        if (!data) {
          data = new Dropzone(this);
          return $this.data('axa.dropzone', data);
        }
      });
    };
    $.fn.dropzone = Plugin;
    $.fn.dropzone.Constructor = Dropzone;
    return $(window).on('load', function() {
      return $('[data-dropzone="dropzone"]').each(function() {
        var $dropzone;
        $dropzone = $(this);
        return Plugin.call($dropzone);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=dropzone.js.map