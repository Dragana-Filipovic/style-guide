(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  (function($) {
    var Plugin, SegmentedControl;
    SegmentedControl = (function() {
      SegmentedControl.DEFAULTS;

      function SegmentedControl(element, options) {
        this.setRadioState = bind(this.setRadioState, this);
        this.handleKeyDown = bind(this.handleKeyDown, this);
        this.handleKeyUp = bind(this.handleKeyUp, this);
        var disabled;
        this.$element = $(element);
        disabled = this.$element.is('[disabled=disabled]');
        this.$radios = this.$element.find('.segmented-control__item__radio');
        this.$radios.each(function(index, element) {
          var $radio;
          $radio = $(element);
          if (disabled) {
            $radio.prop('disabled', 'disabled');
          }
          return $radio.data('item.element', $radio.closest('.segmented-control__item'));
        });
        this.options = $.extend({}, SegmentedControl.DEFAULTS, options);
        this.init();
      }

      SegmentedControl.prototype.init = function() {
        this.$radios.prop('tabindex', '-1');
        this.$element.prop('tabindex', '0');
        this.$element.addClass('segmented-control--js');
        this.setRadioState();
        this.$radios.on('change', this.setRadioState);
        this.$element.on('keyup', this.handleKeyUp);
        this.$element.on('keydown', this.handleKeyDown);
        this.stackControlsIfNeeded();
        return $('window').on('resize', this.stackControlsIfNeeded);
      };

      SegmentedControl.prototype.stackControlsIfNeeded = function() {
        this.$element.removeClass('segmented-control--stacked');
        if (this.$element.outerWidth() >= this.$element.parent().innerWidth()) {
          return this.$element.addClass('segmented-control--stacked');
        }
      };

      SegmentedControl.prototype.handleKeyUp = function(e) {
        var $first;
        if (e.which === 32) {
          e.preventDefault();
          if (this.$radios.filter(':checked').length === 0) {
            $first = $(this.$radios[0]);
            $first.prop('checked', true);
            return $first.change();
          }
        }
      };

      SegmentedControl.prototype.handleKeyDown = function(e) {
        var $checked, $first, $next, $previous;
        switch (e.which) {
          case 32:
            return e.preventDefault();
          case 37:
          case 38:
            e.preventDefault();
            $checked = $(this.$radios.filter(':checked'));
            if ($checked.length !== 0) {
              $previous = $(this.$radios[this.$radios.index($checked) - 1]);
              if (($previous != null) && $previous.length !== 0) {
                $previous.prop('checked', true);
                return $previous.change();
              }
            }
            break;
          case 39:
          case 40:
            e.preventDefault();
            $checked = $(this.$radios.filter(':checked'));
            if ($checked.length === 0) {
              $first = $(this.$radios[1]);
              if (($first != null) & $first.length !== 0) {
                $first.prop('checked', true);
                return $first.change();
              }
            } else {
              $next = $(this.$radios[this.$radios.index($checked) + 1]);
              if (($next != null) && $next.length !== 0) {
                $next.prop('checked', true);
                return $next.change();
              }
            }
        }
      };

      SegmentedControl.prototype.setRadioState = function() {
        return this.$radios.each(function(index, element) {
          var $item, $radio;
          $radio = $(element);
          $item = $radio.data('item.element');
          if ($radio.is(':checked')) {
            return $item.addClass('is-active');
          } else {
            return $item.removeClass('is-active');
          }
        });
      };

      return SegmentedControl;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, data, options;
        $this = $(this);
        options = $.extend({}, SegmentedControl.DEFAULTS, data, typeof option === 'object' && option);
        data = $this.data('axa.segmentedControl');
        if (!data) {
          data = new SegmentedControl(this, options);
          return $this.data('axa.segmentedControl', data);
        }
      });
    };
    $.fn.segmentedControl = Plugin;
    $.fn.segmentedControl.Constructor = SegmentedControl;
    return $(window).on('load', function() {
      return $('[data-segmented-control]').each(function() {
        var $segmentedControl, data;
        $segmentedControl = $(this);
        data = $segmentedControl.data();
        return Plugin.call($segmentedControl, data);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=segmented-control.js.map