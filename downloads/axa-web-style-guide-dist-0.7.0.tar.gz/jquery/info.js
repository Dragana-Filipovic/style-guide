(function() {
  (function($) {
    var Info, Plugin;
    Info = (function() {
      function Info(element, options) {
        var selector;
        this.$element = $(element);
        selector = this.$element.data('target');
        if (selector == null) {
          selector = options.target;
        }
        this.$target = $(selector);
        this.$element.on('click', this, function(event) {
          return event.data.toggle(event);
        });
      }

      Info.prototype.toggle = function() {
        this.$target.slideToggle();
        return this.$element.toggleClass('is-active');
      };

      return Info;

    })();
    Plugin = function(option) {
      var params;
      params = arguments;
      return this.each(function() {
        var $this, action, data, options;
        options = $.extend({}, data, typeof option === 'object' && option);
        if (typeof option === 'string') {
          action = option;
        }
        $this = $(this);
        data = $this.data('axa.info');
        if (!data) {
          data = new Info(this, options);
          return $this.data('axa.info', data);
        }
      });
    };
    $.fn.info = Plugin;
    $.fn.info.Constructor = Info;
    return $(window).on('load', function() {
      return $('[data-info]').each(function() {
        var $info;
        $info = $(this);
        return Plugin.call($info);
      });
    });
  })(jQuery);

}).call(this);

//# sourceMappingURL=info.js.map